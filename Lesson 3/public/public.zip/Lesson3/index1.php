
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Документ без названия</title>
</head>

<body>
<?php
echo "К следующему уроку сдам"

?>


</body>
</html>




